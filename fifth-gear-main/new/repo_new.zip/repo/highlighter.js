// highlighter.js
var words = ["hurry","only"];

// words from your .tsv file
var bodyText = document.body.innerHTML;

for (var i = 0; i < words.length; i++) {
  var regex = new RegExp(words[i], 'gi');
  bodyText = bodyText.replace(regex, function(match) {
    return '<mark>' + match + '</mark>';
  });
}

document.body.innerHTML = bodyText;
